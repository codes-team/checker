import socket
import threading
import time
import os
from queue import Queue
from colorama import *
import webbrowser
webbrowser.open('https://t.me/thomashack')
queue = Queue()
açık_portlar = []
logo='''\x1b[1;31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
\x1b[1;33m
  
@@@@@@@   @@@@@@@    @@@@@@    @@@@@@
@@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@
@@!  @@@  @@!  @@@  @@!  @@@  !@@
!@!  @!@  !@!  @!@  !@!  @!@  !@!
@!@  !@!  @!@  !@!  @!@  !@!  !!@@!!
!@!  !!!  !@!  !!!  !@!  !!!   !!@!!!
!!:  !!!  !!:  !!!  !!:  !!!       !:!
:!:  !:!  :!:  !:!  :!:  !:!      !:!
 :::: ::   :::: ::  ::::: ::  :::: ::
:: :  :   :: :  :    : :  :   :: : :

                 < DDOS VİP TOOL >
              TELE : @PHPMEHMET / @THOMASHACK

\x1b[1;31m ▬▬▬▬▬▬▬▬▬\x1b[1;31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬'''
print(logo)

hedef = input(Fore.CYAN +"[+] URL'yi Girin (örneğin: example.com) >> "+ Style.RESET_ALL)

if hedef =="":
    print('[!] Bu URL bulunamadı')
    time.sleep(3)
    exit()
else:
    pass

nport = input(Fore.CYAN +'[+] Port Aralığı (Varsayılan: 1024) >> '+ Style.RESET_ALL)

if nport == "":
    nport = 1024
else:
    nport = nport

thr = input(Fore.CYAN +'[+] Hız  (Varsayılan: 100) >> '+ Style.RESET_ALL)

if thr =="":
    thr = 100
else:
    thr = thr


def getIP():
    global hedef
    global hostIP
    try:
        hostIP = socket.gethostbyname(hedef)
    except socket.gaierror:
        print('[!] URL geçerli değil..')
        what = input(Fore.CYAN + '[+] Yeniden denemek için [t] girin veya Çıkmak için Enter\'a basın >> '+ Style.RESET_ALL)
        if what == 't':
            hedef = input(Fore.CYAN +'[+] URL\'yi Girin (örneğin: example.com) >> '+ Style.RESET_ALL)
            if hedef =="":
                print('[!] Bu URL bulunamadı')
                time.sleep(3)
                exit()
            else:
                hedef = hedef
                hostIP = socket.gethostbyname(hedef)
        elif what == "":
            time.sleep(3)
            exit()
        else:
            time.sleep(3)
            exit()
        
        return(hostIP)
getIP()

def portscan(port):
    global hostIP
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((hostIP, port))
        return True
    except:
        print(Fore.RED + '[!] Bağlanma Hatası'+Style.RESET_ALL)
        return False
    
def doldur(port_list):
    for port in port_list:
        queue.put(port)

def tarama():
    while not queue.empty():
        port = queue.get()
        if portscan(port):
            print(Fore.GREEN + f'[-] Port {port} açık'+Style.RESET_ALL)
            açık_portlar.append(port)

port_list = range(1,int(nport))
doldur(port_list)

thread_list = []
for t in range(int(thr)):
    thread = threading.Thread(target=tarama)
    thread_list.append(thread)
    
for thread in thread_list:
    thread.start()
    
for thread in thread_list:
    thread.join()
